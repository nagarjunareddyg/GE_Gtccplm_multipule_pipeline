def call(Map pipelineParams) {

  pipeline {
	  agent {
		  node {
			  label 'VDCGLP00680.ics.cloud.ge.com2'
			  customWorkspace "/u01/jenkins_local/wksp_${env.JOB_NAME}"
		  }
	  }
	  options { buildDiscarder(logRotator(numToKeepStr: '50', daysToKeepStr: '30')) }
		
	  
  parameters {
		string(name: 'Environment' )
		string(name: 'WebRelease', description: 'Branch used for Spinner build')
		string(name: 'APP_DB_BUILD_NUMBER', description: 'Auto or Manual Build ')
		string(name: 'BuildType', description: 'Auto or Manual Build ')
		string(name: 'SonarScan', description: 'Run Sonar')
		string(name: 'Junit',  description: 'Run Junit')
		string(name: 'Sast',  description: 'Run Sast')
	  
    } 
	  
 environment {
		current_ws = pwd()
		branch = "${env.BRANCH_NAME}"

		/**  POWER JENKINS: Jenkins tools and credential ids */
		credentials_id='plmenovia_github_cred_id'
		artifactory_repo="QQHDK"
		sonarqube_server='plmenovia-propel-sonarqube'
		sonarqube_scanner='sonarQube Runner'
		artifactory_server='plmenovia_buildge_artifactory_server'
		antTool='ant'
		//jdkTool='jdk1.8'
		coverityTool='cov-analysis-2018.12'
		coverity_server='plm-coverity'

	    /** Constants. Below property is not required for builds in power jekins**/
		//appConfigRepo_git_url="github.build.ge.com/pw-web/applicationConfig.git"
               
	        AWS_PLM_PROXY='iss-americas-pitc-cincinnatiz.proxy.corporate.ge.com:80'
		AWS_PLM_REST_URL='s3-artifacts-uai3026525-us8p'
		aws_credentials_id='GTCCPLM_AWS'
		
	/** Assign values later in stages. **/
		pipelineUtils = ""
		properties = ""
		buildMessage =""
		junitbuildResult=""
				
	 
  
   }
	
stages {
	
stage('Initilize') {
			steps{
			script{
					/* load application properties */
					pipelineUtils = new ge.plm.pipeline.PipelineUtils()
					properties = pipelineUtils.initilize()
									
					/** load input parameters*/
					properties.putAll(params)
					
					print(properties)

			}
			}
		}
			
			
 stage('Code Quality parallel tests') {
		 parallel {
			 		/** SonarScan Stage **/
					stage('SonarScan'){
					when{
					expression {'true'.equalsIgnoreCase(params.SonarScan) && properties.publishType == "db"  }
					}  
					steps {
					script { 
					pipelineUtils.runSonarScan()
					}
					}
					}
			 
			 		/** JUNIT Stage **/
					stage('Junit') {
					when{
					expression { params.Junit == 'true'  && properties.publishType == "db" }
					} 

					steps {
					script { 

					junitbuildResult = build job: properties.Junit_job_name, parameters: [string(name: 'Environment', value: properties.Environment), string(name: 'WebRelease', value: properties.WebRelease)], propagate: false

					}
					}
					}
			 		
			 		/** SAST Stage **/
					stage('SAST'){
					when{
					expression { params.Sast == 'true' }
					}  

					steps {
					script { 
					new ge.plm.pipeline.SastUtils().runSast([properties:properties])
					}
					}
					}
		
		 }
	}
  stage("SonarScan Quality Gate") {
				when { 
					expression { properties.sonarscan_quality_gate == "true" }
				  } 

				steps {
				script {
					timeout(time: 5, unit: 'MINUTES') {
						def qg = waitForQualityGate()
						if (qg.status != 'OK') {
							buildMessage="Pipeline aborted due to sonarqube quality gate failure: ${qg.status}"
							currentBuild.result = 'FAILURE'
							error buildMessage 
							}
						}
					}
				}
              
	   }
	   
	   

	   
	   
  stage('Junit Quality Gate') {
				when {
					expression { properties.junit_quality_gate == "true" } 
				}

				steps {
				script{
					echo 'Junit Quality Gate'
					if(junitbuildResult.result != "SUCCESS")
					buildMessage = "Junit Testcases are failed"
					currentBuild.result = 'FAILURE'
					error buildMessage 
				}
				}
	   }
	   
	   
	

	   
	   
 stage('SAST Quality Gate') {
				when { 
				expression { properties.coverity_quality_gate == "true" }
				}

				steps {
				script{
					echo 'SAST Quality Gate'
					buildMessage = "Coverity issues were found"
					coverityResults abortPipeline: properties.coverity_quality_gate, connectInstance: coverity_server, connectView: properties.coverity_view, projectId: properties.coverity_projectId
					buildMessage=""
				}
				}
	   }
			
	  
	
	   stage('Build') {
				steps {	
				script {
					echo "Build"
					   pipelineUtils.build([properties:properties])
				
					}
				}
		}
			
			
	             
         stage('Publish') {
				
				steps {
				script { 
					echo "Publish"
					pipelineUtils.publish([properties:properties])
				
				}
				}
		  }
	      
  }//stages
  
  

	post{
				success {
					script {
						buildMessage="Success"
						//pipelineUtils.notify([properties:properties , buildMessage:"${buildMessage}"])
						/**  Trigger build Metrics update job */
					//	build job: 'PLM-UPDATE-BUILD-INFO', parameters: [string(name: 'BuildType', value: properties.BuildType), string(name: 'Application', value: properties.application ), string(name: 'Environment', value: properties.Environment ), string(name: 'App_Db_Job_BuildNumber', value:  properties.APP_DB_BUILD_NUMBER), string(name: 'Component', value: properties.publishType), string(name: 'Job_name', value: env.JOB_NAME), string(name: 'Release', value: env.BRANCH_NAME), string(name: 'Build_number', value:  env.BUILD_NUMBER), string(name: 'Duration', value: ''), string(name: 'MetricsFor', value: 'Build')], propagate: false, wait: false

					}
				}
				failure {
					script {
						buildMessage="Failed"
						currentBuild.result = 'FAILURE'
						echo 'Notify on Failed'
						pipelineUtils.notifyOnFailure([properties:properties, buildMessage:"${buildMessage}"])
					}
				}
		
		        	 always { 
				echo '******** Clean Workspace ************'
				cleanWs()
				} 

	    }
	    
	    
				
  } //pipeline
  
  }//def call



